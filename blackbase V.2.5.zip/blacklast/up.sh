git config --global user.email "SeuEmailHeroku@gmail.com"
git config --global user.name "Nome Para Atualizar"